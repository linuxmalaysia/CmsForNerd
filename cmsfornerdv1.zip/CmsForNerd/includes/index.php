<?php

// Redirect people who try to view this folder to the main index.php page
// CmsForNerd

header("Location:../index.php");

?>

