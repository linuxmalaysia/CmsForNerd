<?php

// This is the main theme.php must be called by includes/global-control.php

// CmsForNerd 
// Idea from drupal and xampp and some codes from them
// License GNU Public License V2
// Harisfazillah Jamel v 1.1 7 Feb 2006 linuxmalaysia @ gmail dot com
// Harisfazillah Jamel v 1.2 18 November 2007 linuxmalaysia @ gmail dot com
// For http://www.perempuanmelayu.info/
// For small site without database just pure php html xml code
// Remember all page call this and please check the local
// theme or lang overwrite


$CSSPATH="themes/$THEMENAME/style.css";

//$THEME['css-style']="style.css";

?>
